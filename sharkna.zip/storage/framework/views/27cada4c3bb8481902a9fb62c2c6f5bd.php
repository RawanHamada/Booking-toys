<?php echo e($slot); ?>

<?php /**PATH G:\May 2023\toy project\Book-games\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>